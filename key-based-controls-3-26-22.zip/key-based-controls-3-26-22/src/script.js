// getting canvas element
var canvas=document.getElementById("myCanvas");
var ctx=canvas.getContext("2d");
// set up canvas size 
canvas.width=480;
canvas.height=320;
//setting up ball

var square = {
  x: canvas.width /2,
  y: canvas.height /2,
  size: 30
};
setInterval(update, 20);
//add event listeners
document.addEventListener("keydown", keyDownHandler, false);
document.addEventListener("keyup", keyUpHandler, false);

var rightPressed = false;
var leftPressed = false;
var upPressed = false;
var downPressed = false;

function keyDownHandler(e){
  if (e.keyCode == 39){
    rightPressed = true;
    // code for right key
  } else if (e.keyCode ==37){
    leftPressed = true;
            //code for left key
  }  if (e.keyCode == 38){
    upPressed = true;
    // code for up key
  } else if (e.keyCode == 40){
    downPressed = true;
    //code for down key
   
  }
}
    
function keyUpHandler(e){
  if (e.keyCode == 39){
    // code for right key
    rightPressed = false;
  } else if (e.keyCode ==37){
            //code for left key
    leftPressed = false;
  }  if (e.keyCode == 38){
    // code for up key
    upPressed = false;
  } else if (e.keyCode == 40){
    //code for down key
   downPressed = false;
  }
}


drawSquare();
function drawSquare(){
  ctx.beginPath();
  ctx.rect(square.x, square.y, square.size, square.size);
  ctx.fillStyle = "cyan"
  ctx.fill();
  ctx.closePath();
}

//move the square
function update(){
  
  //update the position based on the key events
  if(rightPressed && square.x <canvas.width - square.size){
    square.x +=7;
  } else if (leftPressed && square.x >0){
    square.x -=7;
  }
  if(upPressed && square.y > 0){
    square.y -=7;
  } else if (downPressed && square.y <canvas.height-square.size){
    square.y +=7;
  }
  //redraw square
  ctx.clearRect(0,0, canvas.width, canvas.height)
  drawSquare();
}
