function greet()
{
  let name = document.getElementById("name").value;
  if (name ===''){
    name = 'world'
  }
  alert('Hello ' + name)
}
  //text size change
document.querySelector('select').onchange= function(){
  document.querySelector('p').style.fontSize =this.value;
}
function newGreet()
{
  let name = document.getElementById("name2").value;
  if(name === ''){
    name = 'world';
  }
  document.getElementById('result').innerHTML= "Thank You " + name ;
}

