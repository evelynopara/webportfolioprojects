document.getElementById("demo").innerHTML = "Hello JavaScript!";
console.log("this is how I debug")
console.log("this is useful to use when I want to test ny program")
console.log("my name is evelyn")

