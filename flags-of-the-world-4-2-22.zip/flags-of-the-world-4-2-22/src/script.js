// js variable for canvas

var France = document.getElementById("france")
var fctx = france.getContext("2d")
france.width = 300;
france.height = 200;
drawRect(fctx, 0, 0, france.width/3, france.height, "blue");
drawRect(fctx, france.width *2/3,0, france.width, france.height, "red");

var Nigeria = document.getElementById("nigeria")
var fctx = nigeria.getContext("2d")
nigeria.width = 300;
nigeria.height = 200;
drawRect(fctx, 0, 0, nigeria.width/3, nigeria.height, "green");
drawRect(fctx, nigeria.width *2/3,0, nigeria.width, nigeria.height, "green");

var Japan = document.getElementById("japan")
var fctx = japan.getContext("2d")
japan.width = 300;
japan.height = 200;
drawCircle(150,100,50,"red");

// helper functions
// create rectangle 
function drawRect(ctx, startx, starty, width, height, color){
  ctx.beginPath();
  ctx.rect(startx, starty, width, height);
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = 1;
  ctx.fill();
  ctx.stroke();
  ctx.closePath();
}

function drawCircle(x,y,r,color){
  fctx.fillStyle = color;
  fctx.beginPath();
  fctx.arc(x,y,r,0,Math.PI *2, false);
  fctx.fill();
  fctx.closePath();
}
  


